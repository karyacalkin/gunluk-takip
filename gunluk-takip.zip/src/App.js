import React, { useState } from "react";

const tasks = [
  { time: "07:10", label: "⏰ Uyanış" },
  { time: "07:15 – 08:30", label: "👧 Beren’i okula bırakma" },
  { time: "08:30 – 08:45", label: "🎧 Spora hazırlık + salona ulaşım" },
  { time: "09:00 – 10:30", label: "🏋️‍♀️ Spor" },
  { time: "10:30 – 11:15", label: "🚶‍♀️ Eve dönüş" },
  { time: "11:15 – 11:45", label: "🚿 Duş + toparlanma" },
  { time: "11:45", label: "💧 1. litre su" },
  { time: "12:00", label: "🍳 Kahvaltı" },
  { time: "13:30", label: "💧 2. litre su" },
  { time: "15:00", label: "🥜 Ara öğün" },
  { time: "16:00", label: "💧 3. litre su" },
  { time: "17:00 – 23:00", label: "💼 Çalışma zamanı" },
  { time: "18:00", label: "🍝 Akşam yemeği" },
  { time: "19:30", label: "💧 4. litre su" },
  { time: "23:00", label: "📊 Muhasebe yap" },
  { time: "23:10", label: "📋 Yoklama al" },
  { time: "23:20", label: "🥤 Kolajen iç" },
  { time: "23:30", label: "🪥 Diş fırçalama" },
  { time: "23:40", label: "🧴 Akşam bakım" },
  { time: "00:00", label: "💤 Uykuya geçiş" }
];

export default function DailyChecklist() {
  const [checked, setChecked] = useState(Array(tasks.length).fill(false));

  const toggleCheck = (index) => {
    const updated = [...checked];
    updated[index] = !updated[index];
    setChecked(updated);
  };

  const completionRate = Math.round(
    (checked.filter((c) => c).length / tasks.length) * 100
  );

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold text-center mb-2">📅 Günlük Takip</h1>
      <p className="text-center text-gray-600 mb-4">
        Bugünün tamamlanma oranı: <span className="font-semibold">{completionRate}%</span>
      </p>
      <div className="grid gap-4">
        {tasks.map((task, index) => (
          <div
            key={index}
            className={\`flex items-center justify-between p-4 rounded-2xl shadow \${checked[index] ? "bg-green-100" : "bg-white"}\`}
          >
            <div>
              <div className="font-semibold">{task.time}</div>
              <div>{task.label}</div>
            </div>
            <input
              type="checkbox"
              checked={checked[index]}
              onChange={() => toggleCheck(index)}
              className="w-5 h-5"
            />
          </div>
        ))}
      </div>
    </div>
  );
}
